﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;


namespace StatementProcessingServiceHost
{
    class Program
    {
       
        static void Main(string[] args)
        {
            using (WebServiceHost host = new WebServiceHost(typeof(StatementProcessingService.ProcessingService)))
            {// ServiceEndpoint endPoint = host.AddServiceEndpoint(typeof(StatementProcessingService.IProcessingService), new WebHttpBinding(), "");
             // ServiceDebugBehavior behaviour = host.Description.Behaviors.Find<ServiceDebugBehavior>();
             // behaviour.HttpHelpPageEnabled = false;
                host.Open();

                //host.
                Console.WriteLine("Service is up and running");
                Console.WriteLine("Press enter to quit ");
                Console.ReadLine();
                host.Close();
            }
        }
    }
}
