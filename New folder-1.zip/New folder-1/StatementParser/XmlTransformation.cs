﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Xsl;

namespace StatementParser
{
    public class XmlTransformation
    {
        public static void TransformationXmlWithXSLT(string xsltFile, string inputFile, string outputFile)
        {
            // Load the XSLT schema into the tranform object
            XslCompiledTransform xslt = new XslCompiledTransform(false);
            using (StreamReader srXslt = new StreamReader(xsltFile))
            {
                XmlReader readerXslt = XmlReader.Create(srXslt);
                xslt.Load(readerXslt);
            }

            // Create and open the output file
            using (FileStream fsOutput = File.Create(outputFile))
            {
                XmlWriterSettings xmlSettings = new XmlWriterSettings();
                xmlSettings.Indent = true;
                XmlWriter writerXML = XmlTextWriter.Create(fsOutput, xmlSettings);

                // Open the input file
                using (XmlReader readerInput = XmlReader.Create(inputFile))
                {
                    xslt.Transform(readerInput, null, writerXML);
                }
            }
        }

        static Dictionary<string, string> nameLookup = new Dictionary<string, string>();

        static void CreateLookupTable()
        {
            // Add the names that requires translation
            nameLookup.Add("PvPAttackRatio_Physical_O", "PVP_ATTACK_RATIO_PHYSICAL");
            nameLookup.Add("damage_physical", "PHYSICAL_DAMAGE");
            nameLookup.Add("hit_accuracy", "PHYSICAL");
            nameLookup.Add("attack_delay", "ATTACK_SPEED");
            nameLookup.Add("physical_defend", "PHYSICAL_DEFENSE");
            nameLookup.Add("PvPAttackRatio_Magical_O", "PVP_ATTACK_RATIO_MAGICAL");
            nameLookup.Add("magical_hit_accuracy", "MAGICAL_ACCURACY");
            nameLookup.Add("dodge", "EVASION");
            nameLookup.Add("PvPDefendRatio_Physical_O", "PVP_DEFEND_RATIO_PHYSICAL");
        }

        static void TransformationXmlWithLinq(string inputFile, string outputFile)
        {
            XDocument xdInput = XDocument.Load(inputFile);

            XElement xeOutputRoot = new XElement("tempering_tables");
            xeOutputRoot.Add(new XAttribute(XNamespace.Xmlns + "xsi", "http://www.w3.org/2001/XMLSchema-instance"));
            xeOutputRoot.Add(new XAttribute(XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance") + "noNamespaceSchemaLocation", "tempering_table.xsd"));

            foreach (XElement xeItemAuthorize in xdInput.Root.Elements(XName.Get("item_authorize")))
            {
                XElement xeTemperingTable = new XElement("tempering_table");
                int id = int.Parse(xeItemAuthorize.Element("id").Value);
                xeTemperingTable.Add(new XAttribute("id", id));

                foreach (XElement xeEnchanterAttribute in xeItemAuthorize.Elements("enchant_attr_list"))
                {
                    foreach (XElement xeData in xeEnchanterAttribute.Elements("data"))
                    {
                        XElement xeModifiers = new XElement("modifiers");

                        foreach (XElement xeDataMembers in xeData.Elements())
                        {
                            if (xeDataMembers.Name.LocalName == "level")
                            {
                                xeModifiers.Add(new XAttribute("level", xeDataMembers.Value));
                            }
                            else if (xeDataMembers.Name.LocalName.StartsWith("attr"))
                            {
                                XElement xeAdd = new XElement("add");

                                string[] parts = xeDataMembers.Value.Split(' ');

                                // No error check what so ever. Needs to be added
                                string name = nameLookup.ContainsKey(parts[0]) ? nameLookup[parts[0]] : parts[0].ToUpper();
                                xeAdd.Add(new XAttribute("name", name));
                                xeAdd.Add(new XAttribute("value", parts[1]));
                                xeAdd.Add(new XAttribute("bonus", true));

                                xeModifiers.Add(xeAdd);
                            }
                            else
                            {
                                throw new Exception(String.Format("Unsupported node found: '{0}'.", xeDataMembers.Name.LocalName));
                            }
                        }

                        xeTemperingTable.Add(xeModifiers);
                    }
                }

                xeOutputRoot.Add(xeTemperingTable);
            }

            // Now save the result in a file
            XDocument xdOutput = new XDocument();
            xdOutput.Declaration = new XDeclaration("1.0", "utf-8", "yes");
            xdOutput.AddAnnotation("Automatic XML translation.");
            xdOutput.Add(xeOutputRoot);
            xdOutput.Save(outputFile);
        }
    }
}
