﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StatementProcessingService
{
   

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "StatementProcessingService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select StatementProcessingService.svc or StatementProcessingService.svc.cs at the Solution Explorer and start debugging.
    public class ProcessingService : IProcessingService, IMonitoringService
    {
        public ProcessingService()
        {
            Console.WriteLine("Service is up and running");
        }
        public string XMLData(string id)
        {
            return "You requested product " + id;
        }

        public string JSONData(string id)
        {
            return "You requested product " + id;
        }

        public string ReadStatementFile()
        {
            return "File Processing";
        }
    }
}
