﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StatementModel;
using BSPWeb.Service;

namespace BSPWeb.controllers
{
    public class StatementController : ApiController
    {
        private StatementService statementService;

        public StatementController()
        {
            this.statementService = new StatementService();
        }
   
        [HttpGet]
        public IEnumerable<Statement> GetAllStatement()
        {
            int Count = 10;
            object[] parameters = { Count };
            return statementService.GetAll(parameters);
        }

        [HttpGet]
        public Statement GetStatementById(int id)
        {
            object[] parameters = { id };
            return statementService.GetbyID(parameters);
        }

        [HttpPost]
        public int InsertStatement(Statement statement)
        {
            object[] parameters = { statement };
            return statementService.Insert(parameters);
        }

        [HttpPost]
        public int UpdateStatement(Statement statement)
        {
            object[] parameters = { statement };
            return statementService.Update(parameters);
        }


        [HttpGet]
        public int DeleteStatement(int id)
        {
            object[] parameters = { id };
            return statementService.Delete(parameters);
        }
    }
}
