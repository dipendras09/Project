﻿// create the module and name it BankStatementApp
(function () {
    'use strict';

    angular.module('BankStatementApp').config(function ($routeProvider, $locationProvider) {
        $routeProvider

            // route for the home page
            .when('', {
                templateUrl: 'Index.html',
                controller: 'IndexController',
                controllerAs: 'vm',
                reloadOnSearch: true
            })
            .when('/home', {
                templateUrl: 'view/Home.html',
                controller: 'HomeController',
                controllerAs: 'vm',
                reloadOnSearch: true
            })
             .when('/dashboard', {
                 templateUrl: 'view/StatementDashboard.html',
                 controller: 'StatementDashboardController',
                 controllerAs: 'vm',
                 reloadOnSearch: true
             })

            // route for the about page
            .when('/statements', {
                templateUrl: 'view/MaintainStatement.html',
                controller: 'MaintainStatementController',
                controllerAs: 'vm',
        reloadOnSearch: true
            })

            // route for the contact page
            .when('/statementdetail', {
                templateUrl: 'view/StatementDetail.html',
                controller: 'StatementDetailController',
                controllerAs: 'vm',
                reloadOnSearch: true
            })
            // route for the contact page
            .when('/failedfiles', {
                templateUrl: 'view/MaintainStatement.html',
                controller: 'MaintainStatementController',
                controllerAs: 'vm',
        reloadOnSearch: true
            })
        ///
            .otherwise({
                templateUrl: 'view/error.html',
               // controller: 'MaintainStatementController',
               // controllerAs: 'vm',
              //  reloadOnSearch: true
            });
        $locationProvider.hashPrefix('');

    })

})();