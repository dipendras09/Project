﻿/// <reference path="C:\Users\Dipen\Projects\AngularJSSamples\WebApplication1\WebApplication1\assets/lib/angular.js" />

(function () {
    'use strict'

    angular.module('BankStatementApp').factory('DataService', ['$http', '$q', DataService]);

    function DataService($http, $q) {
      
        var service = {
            WebAPIGet: WebAPIGet,
            WebAPIGetWithURIParameter: WebAPIGetWithURIParameter,
            WebAPIPostWithParameter: WebAPIPostWithParameter,
            WebAPIPostWithData: WebAPIPostWithData,
            WebAPIPostWithURIParameter: WebAPIPostWithURIParameter,
            WebAPIPostWithDataAndURIParameter: WebAPIPostWithDataAndURIParameter,
            WebAPIGetWithParameter: WebAPIGetWithParameter
        };

        return service;

        function WebAPIGet(Controller, Action, cache) {

            var url = "api/" + Controller + "/" + Action;
            var deferred = $q.defer();

            $http.get(url, { cache: cache })
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIGetError - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }

        function WebAPIGetWithParameter(Controller, Action,parm, cache) {

            var url = "api/" + Controller + "/" + Action + "/" + parm;
            var deferred = $q.defer();

            $http.get(url, { cache: cache })
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIGetWithParameter - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }


        function WebAPIGetWithURIParameter(Controller, Action,uriParameter, cache) {

            var url = "api/" + Controller + "/" + Action + "?" + uriParameter;
            var deferred = $q.defer(); 

            $http.get(url, { cache: cache })
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIGetWithURIParameter - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }

        function WebAPIPostWithParameter(Controller, Action, param) {

            var url = "api/" + Controller + "/" + Action + "/" + param;
            var deferred = $q.defer();

            $http.post(url)
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIPostWithURIParameter - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }

        function WebAPIPostWithData(Controller, Action, data) {

            var url = "api/" + Controller + "/" + Action;
            var deferred = $q.defer();

            $http.post(url, data)
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIPostWithData - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }


        function WebAPIPostWithURIParameter(Controller, Action, uriParameter) {

            var url = "api/" + Controller + "/" + Action + "?" + uriParameter;
            var deferred = $q.defer();

            $http.post(url)
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIPostWithURIParameter - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }

        function WebAPIPostWithDataAndURIParameter(Controller, Action, data, uriParameter) {

            var url = "api/" + Controller + "/" + Action + "?" + uriParameter;
            var deferred = $q.defer();

            $http.post(url, data)
                  .success(function (httpResult) {
                      deferred.resolve(httpResult);

                  }).error(function (response) {
                      deferred.reject(response);
                      throw "Exception: DataService/WebAPIPostWithDataAndURIParameter - Error while calling the url '" + url + "'. Message: "
                      + (response.Message == undefined ? response : response.Message);
                  })
            return deferred.promise;
        }
    }
})();