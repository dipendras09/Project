﻿(function () {
    'use strict'

    angular.module('BankStatementApp').constant('Constants', {

        Controllers: {
            StatementController: 'Statement',
            CommonController: 'Common'
        },

        StatementController: {
            Actions: {
                GetAllStatement: "GetAllStatement",
                GetStatementById: "GetStatementById",
                InsertStatement: "InsertStatement",
                DeleteStatement: "DeleteStatement",
                UpdateStatement: "UpdateStatement"
            }
        },

        CacheResponse: {
            Yes: true,
            No: false
        }
    });
})();