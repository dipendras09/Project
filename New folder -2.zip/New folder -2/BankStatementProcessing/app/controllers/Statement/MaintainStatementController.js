﻿(function () {
    'use strict';

    angular.module('BankStatementApp').controller('MaintainStatementController', ['$scope', '$location', MaintainStatementController])
    // Data to be edited in the form
    // (would normally by fetched from the server)
    function MaintainStatementController($scope, $location) {
        var vm = this;

        vm.Test = 'Welcome Statement';

        $scope.groups = [{
            "id": 1,
            "statement": "BOA",
            "status": 'Success'
      
        }, {
            "id": 2,
            "statement": "Central",
            "status": 'Success'
        }, {
            "id": 3,
            "statement": "SBI",
            "status": 'Pending'
        }];
    }
})();