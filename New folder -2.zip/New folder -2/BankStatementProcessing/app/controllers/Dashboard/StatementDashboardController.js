﻿(function () {
    'use strict';

    angular.module('BankStatementApp').controller('StatementDashboardController', ['$scope', '$location', StatementDashboardController])
    // Data to be edited in the form
    // (would normally by fetched from the server)
    function StatementDashboardController($scope, $location) {
        var vm = this;

        vm.Test = 'Welcome Dashboard';

        $scope.groups = [{
            "id": 1,
            "members": [
                { "name": "Sue", "age": 48 },
                { "name": "Jane", "age": 12 },
                { "name": "Edna", "age": 10 }
            ]
        }, {
            "id": 2,
            "members": [
                { "name": "Harry", "age": 45 },
                { "name": "Brian", "age": 18 }
            ]
        }, {
            "id": 3,
            "members": [
                { "name": "Spot", "age": 2 },
                { "name": "Whiskers", "age": 7 }
            ]
        }];
    }
})();