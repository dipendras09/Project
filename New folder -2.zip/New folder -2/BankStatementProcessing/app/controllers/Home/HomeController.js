﻿(function () {
    'use strict';

    angular.module('BankStatementApp').controller('HomeController', ['$scope', '$location', HomeController])
    // Data to be edited in the form
    // (would normally by fetched from the server)
    function HomeController($scope, $location) {
        var vm = this;

        vm.Test = 'Welcome Home page';
    }
})();