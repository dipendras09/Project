﻿
(function () {
    'use strict';

    angular.module('BankStatementApp').controller('IndexController', ['$scope','$location', IndexController])

    function IndexController($scope,$location) {

    }
 
})();