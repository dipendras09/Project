﻿'use strict';

// Declares how the application should be bootstrapped. See: http://docs.angularjs.org/guide/module
(function () {
    angular.module('BankStatementApp', [
        'ngRoute',
        'ngAnimate',
        'ngSanitize'
    ]);

})();
  
  