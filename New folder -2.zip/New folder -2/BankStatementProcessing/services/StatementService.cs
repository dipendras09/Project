﻿using System.Collections.Generic;
using StatementRepository;
using StatementModel;

namespace BSPWeb.Service
{
    public class StatementService
    {
        private GenericRepository<Statement> statementRepository;
        
        public StatementService()
        {
            this.statementRepository = new GenericRepository<Statement>(new Statement_ModelContainer());
        }

        public IEnumerable<Statement> GetAll(object[] parameters)
        {
            string spQuery = "[proc_GetAllStatment] {0}";
            return statementRepository.ExecuteQuery(spQuery, parameters);
        }

        public Statement GetbyID(object[] parameters)
        {
            string spQuery = "[proc_GetStatementbyID] {0}";
            return statementRepository.ExecuteQuerySingle(spQuery, parameters);
        }

        public int Insert(object[] parameters)
        {
            string spQuery = "[proc_InsertStatement] {0}, {1}";
            return statementRepository.ExecuteCommand(spQuery, parameters);
        }

        public int Update(object[] parameters)
        {
            string spQuery = "[proc_UpdateStatement] {0}, {1}, {2}";
            return statementRepository.ExecuteCommand(spQuery, parameters);
        }

        public int Delete(object[] parameters)
        {
            string spQuery = "[proc_DeleteStatment] {0}";
            return statementRepository.ExecuteCommand(spQuery, parameters);
        }
    }
}