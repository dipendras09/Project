﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using StatementParser;

namespace TestXMLTransformation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputXSLT = Convert.ToString(ConfigurationManager.AppSettings["pathXSLT"]);
            string inpuXML = Convert.ToString(ConfigurationManager.AppSettings["inputXML"]);
            //string inpuXML = Convert.ToString(ConfigurationManager.AppSettings["inputXML"]);
            XmlTransformation.TransformationXmlWithXSLT(inputXSLT, inpuXML, @"OutputXML_xslt.xml");
        }
    }
}
