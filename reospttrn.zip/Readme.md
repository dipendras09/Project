## Repository Pattern For .Net Sample
#### Multiple Datasource or Resource on Domain Object Model
This project is sample for Codeproject