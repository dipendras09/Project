﻿namespace RepositoryPattern.Repository
{
    public enum ContextTypes
    {
        EntityFramework,
        XMLSource
    }
}
